# apiSDO
An API for the Nasa Solar Dynamics Observatory
